Made By crazyyanman GITHUB.

Make sure you are logged into the correct computer account then run the .exe file

Simple as that

DISCLAIMER**

Make sure to turn off all anti-viruses, this is because some antiviruses see this file as a false positive (Meaning it thinks its a virus)